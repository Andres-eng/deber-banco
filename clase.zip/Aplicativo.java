public class Aplicativo{
	public static void main(String []args){
		Menu obj1=new Menu();
		obj1.menu();
	}
}